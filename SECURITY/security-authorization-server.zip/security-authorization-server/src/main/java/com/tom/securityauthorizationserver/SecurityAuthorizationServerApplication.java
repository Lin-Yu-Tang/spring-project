package com.tom.securityauthorizationserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityAuthorizationServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityAuthorizationServerApplication.class, args);
	}

}

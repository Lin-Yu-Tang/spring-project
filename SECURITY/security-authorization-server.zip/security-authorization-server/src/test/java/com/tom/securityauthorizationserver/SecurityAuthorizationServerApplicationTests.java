package com.tom.securityauthorizationserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityAuthorizationServerApplicationTests {

	@Test
	void contextLoads() {
	}

}

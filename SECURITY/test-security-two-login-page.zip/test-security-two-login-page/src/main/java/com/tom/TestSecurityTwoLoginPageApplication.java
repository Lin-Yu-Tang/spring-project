package com.tom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestSecurityTwoLoginPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestSecurityTwoLoginPageApplication.class, args);
	}

}
